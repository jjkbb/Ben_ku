This Evaluation kits for GP2AP03VT00F include;

/GP2AP03VT00F_EvaluationKit_vxxx
|--Docs
|  |--EvaluationKit_how_to_connect_ToF.pdf          //How to connect a sensor to evaluation kit
|  |--GP2AP03VT_SoftwareManual_v100ENG.PDF          //How to use a sensor driver software in English
|  |--GP2AP03VT_SoftwareManual_v100JPN.PDF          //How to use a sensor driver software in Japanese
|  |--GP2AP03VT_UserManual_v100.pdf                 //Detailed description for sensor functions and registers
|  |--GP2AP03VT_WindowsApplicationManual_v100.pdf   //How to use windows application of an evaluation kit
|  |--GP2AP03VT00F_Specification_V00.pdf            //Data sheet for GP2AP03VT00F
|--WindowsAPP
|  |--gp2ap03vt_winapp_v102
|  |  |--gp2ap03vt.exe                              //Executable file of Windows app
|  |  |--gp2ap03vt.exe.config


